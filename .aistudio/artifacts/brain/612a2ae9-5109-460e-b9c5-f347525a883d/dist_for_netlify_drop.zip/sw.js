/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  importScripts("/sw-notifications.js");
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sw-notifications.js",
    "revision": "d7b3c10d1d4863559326da64ab18b139"
  }, {
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "7cae3e44b3bb7b6cffd7fe487b504b9d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8f746d79c39f6989bb36ba83972671ba"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9f7dd61db85ccef5a5f6baa0fb745c86"
  }, {
    "url": "index.html",
    "revision": "543590017d629abf5b3554aaf46ab19c"
  }, {
    "url": "icon.svg",
    "revision": "d2c63e888adc2d1f644cec699ac64547"
  }, {
    "url": "emblem-of-nepal.svg",
    "revision": "a51dd46acb3c53c5a95c8b87480c86b5"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "bc31c778a688d4b8092a2213b6672068"
  }, {
    "url": "assets/purify.es-Dqk5qvad.js",
    "revision": null
  }, {
    "url": "assets/index.es-BWEeuN7y.js",
    "revision": null
  }, {
    "url": "assets/index-D9tuOJXR.css",
    "revision": null
  }, {
    "url": "assets/index-C1CxcpDG.js",
    "revision": null
  }, {
    "url": "assets/html2canvas-tGS_loit.js",
    "revision": null
  }, {
    "url": "assets/emblem-of-nepal-CPnGykOQ.svg",
    "revision": null
  }, {
    "url": "assets/aistudio/image_dd550a7e.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_a4cbe912.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_9fb85f3f.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Your_paragraph_text_69a87b11.png",
    "revision": null
  }, {
    "url": "pwa-192x192.png",
    "revision": "9f7dd61db85ccef5a5f6baa0fb745c86"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8f746d79c39f6989bb36ba83972671ba"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "7cae3e44b3bb7b6cffd7fe487b504b9d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "fa36bd7a45d7a96705b7585dc4c695d6"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
